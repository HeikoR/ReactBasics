import React, { Component } from 'react';

class NumberChange extends Component {

	/**
	 * constructor
	 */
	constructor(props) {
		super(props);

		//Bind events - https://reactjs.org/docs/handling-events.html
		this.handleIncrement = this.handleIncrement.bind(this);
		this.handleDecrement = this.handleDecrement.bind(this);

		//Create state
		this.state = {
			counter: 0
		};
	}

	/**
	 * handleIncrement
	 * increases the number
	 */
	handleIncrement() {

		//update state - https://reactjs.org/docs/state-and-lifecycle.html
		this.setState((prevState, props) => ({
			counter: prevState.counter + 1
		}));
	}

	/**
	 * handleDecrement
	 * decreases the number
	 */
	handleDecrement() {

		//update state - https://reactjs.org/docs/state-and-lifecycle.html
		this.setState((prevState, props) => ({
			counter: prevState.counter - 1
		}));
	}

	//The best way to learn React: https://reactjs.org/docs/hello-world.html
	render() {
		return (
			<div>
				<p>{this.state.counter}</p>
				<button onClick={this.handleIncrement}>+</button>
				<button onClick={this.handleDecrement}>-</button>
			</div>
		);
	}

}

export default NumberChange;
