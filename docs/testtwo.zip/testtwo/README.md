#Step 1:

	npm install

#Step 2:

	npm start

#Step 3:

	Go look at your index.js file in the src directory

#Test:

	Add Redux to this application. Keep the 5 instances of NumberChange. Make them share the state of the number value and have them update this state with Redux actions.
